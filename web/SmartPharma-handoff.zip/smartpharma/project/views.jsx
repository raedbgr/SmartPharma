// --- Reusable view components ---

const { useMemo, useState } = React;

// Sparkline mini chart
function Spark({ pts = [], stroke = 'currentColor', w = 70, h = 26 }) {
  const max = Math.max(...pts), min = Math.min(...pts);
  const span = max - min || 1;
  const dx = w / (pts.length - 1);
  const d = pts.map((v, i) => `${i === 0 ? 'M' : 'L'} ${(i * dx).toFixed(2)} ${(h - ((v - min) / span) * h).toFixed(2)}`).join(' ');
  return (
    <svg width={w} height={h} className="spark" viewBox={`0 0 ${w} ${h}`} fill="none">
      <path d={d} stroke={stroke} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// Demand vs prediction chart with shaded band
function DemandChart({ accent = 'oklch(0.42 0.06 175)' }) {
  const W = 720, H = 230, P = { l: 36, r: 14, t: 16, b: 28 };
  const data = window.SERIES;
  const ys = data.flatMap(d => [d.demand, d.pred]);
  const yMin = Math.min(...ys) - 60;
  const yMax = Math.max(...ys) + 60;
  const xs = (i) => P.l + (i / (data.length - 1)) * (W - P.l - P.r);
  const ysc = (v) => P.t + (1 - (v - yMin) / (yMax - yMin)) * (H - P.t - P.b);

  const demandPath = data.map((d, i) => `${i ? 'L' : 'M'} ${xs(i).toFixed(1)} ${ysc(d.demand).toFixed(1)}`).join(' ');
  const predPath = data.map((d, i) => `${i ? 'L' : 'M'} ${xs(i).toFixed(1)} ${ysc(d.pred).toFixed(1)}`).join(' ');
  // confidence band ±60
  const bandTop = data.map((d, i) => `${i ? 'L' : 'M'} ${xs(i).toFixed(1)} ${ysc(d.pred + 60).toFixed(1)}`).join(' ');
  const bandBot = [...data].reverse().map((d, i) => {
    const j = data.length - 1 - i;
    return `L ${xs(j).toFixed(1)} ${ysc(d.pred - 60).toFixed(1)}`;
  }).join(' ');

  // x axis labels (every 7)
  const labels = [];
  for (let i = 0; i < data.length; i += 7) {
    labels.push({ i, label: `J-${27 - i}` });
  }
  // y grid lines
  const yTicks = 4;
  const grid = [];
  for (let k = 0; k <= yTicks; k++) {
    const v = yMin + (yMax - yMin) * (k / yTicks);
    grid.push({ y: ysc(v), v: Math.round(v) });
  }

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="chart" preserveAspectRatio="none">
      {grid.map((g, i) => (
        <g key={i}>
          <line x1={P.l} x2={W - P.r} y1={g.y} y2={g.y} stroke="rgba(20,20,15,0.06)" />
          <text x={P.l - 8} y={g.y + 3} textAnchor="end" fontFamily="Geist Mono, monospace" fontSize="9" fill="#A5A498">{g.v}</text>
        </g>
      ))}
      {labels.map((l, i) => (
        <text key={i} x={xs(l.i)} y={H - 6} textAnchor="middle" fontFamily="Geist Mono, monospace" fontSize="9.5" fill="#A5A498">{l.label}</text>
      ))}
      {/* AI confidence band */}
      <path d={`${bandTop} ${bandBot} Z`} fill={accent} opacity="0.10" />
      {/* prediction (dashed) */}
      <path d={predPath} fill="none" stroke={accent} strokeWidth="1.4" strokeDasharray="4 4" />
      {/* demand */}
      <path d={demandPath} fill="none" stroke="#14140F" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      {/* end dot */}
      <circle cx={xs(data.length - 1)} cy={ysc(data[data.length - 1].demand)} r="3.2" fill="#14140F" />
      <circle cx={xs(data.length - 1)} cy={ysc(data[data.length - 1].demand)} r="6" fill="#14140F" opacity="0.10" />
      {/* "today" axis marker between past and forecast */}
      <line x1={xs(20)} x2={xs(20)} y1={P.t} y2={H - P.b} stroke="rgba(20,20,15,0.18)" strokeDasharray="2 3" />
      <text x={xs(20)} y={P.t - 4} textAnchor="middle" fontFamily="Geist Mono, monospace" fontSize="9" fill="#6E6E63">AUJOURD'HUI</text>
    </svg>
  );
}

// KPI tile
function KPI({ label, value, unit, delta, deltaDir, spark }) {
  return (
    <div className="kpi reveal">
      <div className="lbl">{label}</div>
      <div className="val num">{value}{unit && <span className="unit">{unit}</span>}</div>
      <div className={`delta ${deltaDir || ''}`}>
        {deltaDir === 'up' && <window.I.ArrowUp size={11}/>}
        {deltaDir === 'down' && <window.I.ArrowDown size={11}/>}
        <b>{delta}</b> <span>vs. 30j</span>
      </div>
      {spark && <Spark pts={spark} stroke={deltaDir === 'down' ? 'oklch(0.62 0.18 30)' : 'oklch(0.42 0.06 175)'} />}
    </div>
  );
}

// Expiration thermometer row
function ExpRow({ name, qty, daysLeft }) {
  // 0..180 days mapped to 0..100%
  const pct = Math.max(0, Math.min(100, (daysLeft / 180) * 100));
  let zone = 'amber';
  if (daysLeft < 30) zone = 'warn'; else if (daysLeft > 90) zone = 'ok';
  return (
    <div className="therm-row">
      <div>
        <div className="name">{name}</div>
        <div className="qty">{qty} unités · J-{daysLeft}</div>
      </div>
      <div className="therm-bar">
        <i className="seg-180" style={{ width: '100%' }} />
        <i className="seg-90" style={{ width: '50%' }} />
        <i className="seg-30" style={{ width: '17%' }} />
        <i className="mark" style={{ left: `calc(${pct}% - 1px)` }} />
      </div>
      <div className="num" style={{ textAlign: 'right', fontFamily: 'Geist Mono, monospace', fontSize: 11, color: 'var(--ink-3)' }}>{daysLeft}j</div>
    </div>
  );
}

// Stock bar
function StockBar({ stock, min }) {
  const pct = Math.min(100, (stock / Math.max(min * 3, 1)) * 100);
  let cls = 'ok';
  if (stock < min) cls = 'low'; else if (stock < min * 1.5) cls = 'med';
  return (
    <span>
      <span className="stockbar"><i className={cls} style={{ width: `${pct}%` }} /></span>
      <span className="num">{stock.toLocaleString('fr-FR')}</span>
      <span style={{ color: 'var(--ink-4)', fontSize: 11, marginLeft: 6 }}>/ {min}</span>
    </span>
  );
}

// Pred row
function PredRow({ p }) {
  return (
    <div className="pred-row">
      <div>
        <div className="pn">{p.name}</div>
        <div className="pm">{p.cls} · confiance {Math.round(p.conf * 100)}%</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div className={`when-tag ${p.kind === 'amber' ? 'amber' : ''}`}>rupture J+{p.etaDays}</div>
      </div>
    </div>
  );
}

window.Spark = Spark;
window.DemandChart = DemandChart;
window.KPI = KPI;
window.ExpRow = ExpRow;
window.StockBar = StockBar;
window.PredRow = PredRow;
