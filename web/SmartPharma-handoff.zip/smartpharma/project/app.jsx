// --- SmartPharma main app ---

const { useState, useEffect, useMemo } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentHue": 175,
  "density": "regular",
  "dark": false,
  "showAIBanner": true,
  "headline": "Bonjour Dr. Hadid"
}/*EDITMODE-END*/;

const NAV_TOP = [
  { id: 'dash', label: 'Tableau de bord', icon: 'Dashboard' },
  { id: 'stock', label: 'Inventaire', icon: 'Box' },
  { id: 'alerts', label: 'Alertes', icon: 'Bell', count: 3 },
  { id: 'ai', label: 'IA · Prédictions', icon: 'Sparkles' },
  { id: 'expir', label: 'Péremptions', icon: 'Calendar' },
];
const NAV_BOT = [
  { id: 'orders', label: 'Commandes', icon: 'Truck' },
  { id: 'analytics', label: 'Analytique', icon: 'Chart' },
  { id: 'team', label: 'Équipe', icon: 'Users' },
  { id: 'settings', label: 'Paramètres', icon: 'Gear' },
];

function Sidebar({ view, setView }) {
  const renderItem = (it) => {
    const Ic = window.I[it.icon];
    return (
      <button key={it.id} className={`nav-item ${view === it.id ? 'active' : ''}`} onClick={() => setView(it.id)}>
        <Ic />
        <span>{it.label}</span>
        {it.count && <span className="count">{it.count}</span>}
      </button>
    );
  };
  return (
    <aside className="side">
      <div className="brand">
        <div className="brand-mark" />
        <div>
          <div className="brand-name">SmartPharma</div>
          <div className="brand-sub">Nerolina · AI Stock</div>
        </div>
      </div>
      <div className="nav-group">
        <div className="nav-label">Opérations</div>
        {NAV_TOP.map(renderItem)}
      </div>
      <div className="nav-group">
        <div className="nav-label">Gestion</div>
        {NAV_BOT.map(renderItem)}
      </div>
      <div className="side-foot">
        <div className="avatar">SH</div>
        <div>
          <div className="who">Dr. Sarah Hadid</div>
          <div className="role">Pharmacie Centrale</div>
        </div>
      </div>
    </aside>
  );
}

function Topbar({ view, openAdd, setQuery, query }) {
  const VIEW_TITLES = {
    dash: 'Tableau de bord',
    stock: 'Inventaire',
    alerts: 'Alertes',
    ai: 'Prédictions IA',
    expir: 'Péremptions',
    orders: 'Commandes',
    analytics: 'Analytique',
    team: 'Équipe',
    settings: 'Paramètres',
  };
  return (
    <div className="topbar">
      <div className="crumbs">SmartPharma <span style={{ margin: '0 6px', color: 'var(--ink-4)' }}>/</span> <b>{VIEW_TITLES[view]}</b></div>
      <div className="search">
        <window.I.Search size={14} />
        <input placeholder="Rechercher un médicament, lot, fournisseur…" value={query} onChange={e => setQuery(e.target.value)} />
        <span className="kbd">⌘K</span>
      </div>
      <button className="iconbtn" title="Notifications"><window.I.Bell /><span className="dot" /></button>
      <button className="btn btn-ghost"><window.I.Download size={13}/>Exporter</button>
      <button className="btn btn-primary" onClick={openAdd}><window.I.Plus size={13}/>Ajouter</button>
    </div>
  );
}

function DashView({ t }) {
  return (
    <>
      <div className="page-hd">
        <div>
          <h1 className="reveal">{t.headline}, <em>tout est sous contrôle</em></h1>
          <p>Aperçu en temps réel de votre stock pharmaceutique. L'IA surveille 1 248 références et anticipe les ruptures.</p>
        </div>
        <div className="page-meta">
          <div className="live"><span className="live-dot" /> Synchronisé à l'instant</div>
          <div style={{ marginTop: 4, fontFamily: 'Geist Mono, monospace' }}>12 mai 2026 · 14:42</div>
        </div>
      </div>

      <div className="kpi-row">
        <window.KPI label="Références actives" value="1 248" delta="+3,2 %" deltaDir="up" spark={[3,5,4,6,7,6,8,9,8,10,11,12]} />
        <window.KPI label="Valeur du stock" value="284 920" unit="€" delta="+1,4 %" deltaDir="up" spark={[8,7,9,8,10,11,10,12,11,13,12,14]} />
        <window.KPI label="Ruptures prévues 30j" value="12" delta="−4" deltaDir="up" spark={[14,15,12,14,13,11,12,10,9,11,10,9]} />
        <window.KPI label="Lots proches péremption" value="38" delta="+6" deltaDir="down" spark={[6,7,6,8,9,8,10,11,12,11,13,12]} />
      </div>

      <div className="grid-2">
        <section className="card reveal">
          <div className="card-hd">
            <div>
              <h3>Demande vs. prévision IA</h3>
              <div className="sub">28 derniers jours · projection à 7 jours</div>
            </div>
            <div className="tools">
              <span className="pill live">Nerolina v2.4</span>
              <button className="iconbtn" style={{ width: 28, height: 28 }}><window.I.Dots size={14}/></button>
            </div>
          </div>
          <div className="legend">
            <span><span className="sw" style={{ background: 'var(--ink)' }} />Demande réelle</span>
            <span><span className="sw" style={{ background: 'var(--accent)', backgroundImage: 'repeating-linear-gradient(90deg, var(--accent) 0 4px, transparent 4px 8px)' }} />Prévision IA</span>
            <span><span className="sw" style={{ background: 'var(--accent-soft)' }} />Intervalle de confiance 95%</span>
          </div>
          <div className="chart-wrap"><window.DemandChart /></div>
        </section>

        <section className="card reveal">
          <div className="card-hd">
            <div>
              <h3>Alertes en cours</h3>
              <div className="sub">3 critiques · 2 à surveiller</div>
            </div>
            <span className="pill warn">Action requise</span>
          </div>
          <div className="alert-list">
            {window.ALERTS.map(a => (
              <div key={a.id} className={`alert ${a.sev}`}>
                <div className="bar" />
                <div>
                  <div className="title">{a.title}</div>
                  <div className="meta">
                    {a.meta.map((m, i) => (
                      <React.Fragment key={i}>
                        <span>{m}</span>
                        {i < a.meta.length - 1 && <span className="dot" />}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
                <div className="when">{a.when}</div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="grid-3">
        <section className="pred reveal">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span className="ai-tag"><window.I.Sparkles size={11}/>Nerolina prédit</span>
            <span className="pill">temps réel</span>
          </div>
          <div className="ask">
            <em>4 médicaments</em> risquent une rupture sous <em>3 semaines</em>. Réapprovisionnement recommandé aujourd'hui.
          </div>
          <div style={{ borderTop: '1px solid var(--line-2)', paddingTop: 4 }}>
            {window.PREDICTIONS.map((p, i) => <window.PredRow key={i} p={p} />)}
          </div>
          <div className="pred-foot">
            <div className="conf">
              <span>Confiance modèle</span>
              <span className="bar"><i /></span>
              <span className="num" style={{ color: 'var(--ink)', whiteSpace: 'nowrap' }}>88 %</span>
            </div>
            <button className="btn btn-primary" style={{ padding: '8px 14px', fontSize: 12, whiteSpace: 'nowrap' }}>Générer commande</button>
          </div>
        </section>

        <section className="card reveal">
          <div className="card-hd">
            <div>
              <h3>Calendrier péremption</h3>
              <div className="sub">Top 5 lots prioritaires</div>
            </div>
            <span className="pill amber">60j</span>
          </div>
          <div className="therm">
            <window.ExpRow name="Insuline Lantus" qty={42} daysLeft={17} />
            <window.ExpRow name="Augmentin 1g" qty={64} daysLeft={38} />
            <window.ExpRow name="Smecta Orange" qty={96} daysLeft={60} />
            <window.ExpRow name="Ibuprofène 400mg" qty={312} daysLeft={82} />
            <window.ExpRow name="Amoxicilline 500mg" qty={412} daysLeft={125} />
            <div className="therm-axis"><span>J+0</span><span>J+30</span><span>J+90</span><span>J+180</span></div>
          </div>
        </section>

        <section className="card reveal">
          <div className="card-hd">
            <div>
              <h3>Activité de l'équipe</h3>
              <div className="sub">Aujourd'hui</div>
            </div>
            <button className="iconbtn" style={{ width: 28, height: 28 }}><window.I.Dots size={14}/></button>
          </div>
          <div className="feed">
            {window.ACTIVITY.map((a, i) => {
              const ic = a.kind === 'warn' ? <window.I.Bell size={12}/> :
                         a.kind === 'ok' ? <window.I.Check size={12}/> :
                         a.kind === 'amber' ? <window.I.Calendar size={12}/> :
                         a.kind === 'acc' ? <window.I.Sparkles size={12}/> :
                         <window.I.Plus size={12}/>;
              return (
                <div className="feed-row" key={i}>
                  <div className={`ic ${a.kind === 'default' ? '' : a.kind}`}>{ic}</div>
                  <div className="t">{a.t}</div>
                  <div className="when">{a.when}</div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </>
  );
}

function StockView({ query }) {
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState(null);
  const rows = useMemo(() => {
    let r = window.MEDS;
    if (filter === 'low') r = r.filter(m => m.stock < m.min * 1.5);
    if (filter === 'crit') r = r.filter(m => m.stock < m.min);
    if (filter === 'ok') r = r.filter(m => m.stock >= m.min * 1.5);
    if (query) {
      const q = query.toLowerCase();
      r = r.filter(m => m.name.toLowerCase().includes(q) || m.cls.toLowerCase().includes(q) || m.supplier.toLowerCase().includes(q));
    }
    return r;
  }, [filter, query]);

  return (
    <>
      <div className="page-hd">
        <div>
          <h1>Inventaire <em>complet</em></h1>
          <p>1 248 références suivies en temps réel · Dernière synchronisation il y a 4 secondes</p>
        </div>
        <div className="page-meta">
          <div className="live"><span className="live-dot" /> Stock à jour</div>
        </div>
      </div>

      <div className="toolbar">
        <div className="seg">
          <button className={filter === 'all' ? 'on' : ''} onClick={() => setFilter('all')}>Tous · {window.MEDS.length}</button>
          <button className={filter === 'crit' ? 'on' : ''} onClick={() => setFilter('crit')}>Critique</button>
          <button className={filter === 'low' ? 'on' : ''} onClick={() => setFilter('low')}>Bas</button>
          <button className={filter === 'ok' ? 'on' : ''} onClick={() => setFilter('ok')}>OK</button>
        </div>
        <span className="chip"><window.I.Filter size={12}/>Classe thérapeutique</span>
        <span className="chip"><window.I.Truck size={12}/>Fournisseur</span>
        <span className="chip"><window.I.Calendar size={12}/>Péremption</span>
        <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--ink-3)' }}>{rows.length} résultats</span>
      </div>

      <div style={{ padding: '0 32px 32px' }}>
        <div className="card">
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: 30 }}><input type="checkbox" /></th>
                <th>Médicament</th>
                <th>Classe</th>
                <th>Stock / Seuil</th>
                <th>Péremption</th>
                <th>Fournisseur</th>
                <th>Emplacement</th>
                <th style={{ textAlign: 'right' }}>Prix</th>
                <th style={{ width: 40 }}></th>
              </tr>
            </thead>
            <tbody>
              {rows.map(m => {
                const status = m.stock < m.min ? 'warn' : m.stock < m.min * 1.5 ? 'amber' : 'ok';
                const label = status === 'warn' ? 'Critique' : status === 'amber' ? 'Bas' : 'OK';
                return (
                  <tr key={m.id} className={selected === m.id ? 'sel' : ''} onClick={() => setSelected(m.id)}>
                    <td><input type="checkbox" onClick={e => e.stopPropagation()} /></td>
                    <td>
                      <div className="name">{m.name}</div>
                      <div className="sku">{m.id}</div>
                    </td>
                    <td>{m.cls}</td>
                    <td><window.StockBar stock={m.stock} min={m.min} /></td>
                    <td>
                      <span className="num">{new Date(m.exp).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                      <span className={`pill ${status}`} style={{ marginLeft: 8 }}>{label}</span>
                    </td>
                    <td>{m.supplier}</td>
                    <td><span className="mono" style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>{m.loc}</span></td>
                    <td style={{ textAlign: 'right' }} className="num">{m.price.toFixed(2)} €</td>
                    <td><button className="iconbtn" style={{ width: 28, height: 28 }}><window.I.Dots size={14}/></button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

function AIView() {
  return (
    <>
      <div className="page-hd">
        <div>
          <h1>Prédictions <em>Nerolina AI</em></h1>
          <p>Modèle entraîné sur 18 mois de données de ventes, saisonnalité, prescriptions et alertes sanitaires locales.</p>
        </div>
        <div className="page-meta">
          <div className="live"><span className="live-dot" /> Modèle v2.4 · recalculé il y a 3 min</div>
        </div>
      </div>

      <div className="kpi-row">
        <window.KPI label="Précision moyenne" value="92,4" unit="%" delta="+1,8 pts" deltaDir="up" spark={[6,7,8,7,9,10,11,10,12,11,13,12]} />
        <window.KPI label="Ruptures évitées (30j)" value="47" delta="+11" deltaDir="up" spark={[3,4,5,6,6,7,8,9,10,11,12,13]} />
        <window.KPI label="Économies estimées" value="18 240" unit="€" delta="+22 %" deltaDir="up" spark={[4,5,7,8,9,10,11,12,13,14,15,16]} />
        <window.KPI label="Stocks dormants détectés" value="9" delta="−3" deltaDir="up" spark={[12,11,10,11,9,10,8,9,7,8,6,7]} />
      </div>

      <div className="grid-2">
        <section className="card reveal">
          <div className="card-hd">
            <div>
              <h3>Recommandations actives</h3>
              <div className="sub">Triées par impact financier estimé</div>
            </div>
            <span className="pill live">12 actions</span>
          </div>
          <div className="alert-list">
            {[
              { sev: 'warn', t: 'Commander 200 doses Ventoline 100µg', m: ['Évite rupture prévue J+3', 'Économie : 1 240 €'], w: '94%' },
              { sev: 'warn', t: 'Réapprovisionner Insuline Lantus', m: ['Stock + péremption à risque', 'Lot suivant disponible J+5'], w: '88%' },
              { sev: 'amber', t: 'Réduire commande Doliprane 500mg', m: ['Sur-stock détecté · +180 unités', 'Recommandé : −400 unités'], w: '81%' },
              { sev: 'amber', t: 'Promouvoir Smecta Orange en officine', m: ['96 unités à écouler avant J+60', 'Suggestion : remise −15 %'], w: '76%' },
              { sev: 'ok', t: 'Programmer commande hebdo (Sanofi)', m: ['Mardi 19 mai · 14 références'], w: '92%' },
            ].map((a, i) => (
              <div key={i} className={`alert ${a.sev}`}>
                <div className="bar" />
                <div>
                  <div className="title">{a.t}</div>
                  <div className="meta">{a.m.map((x, j) => <React.Fragment key={j}><span>{x}</span>{j < a.m.length - 1 && <span className="dot"/>}</React.Fragment>)}</div>
                </div>
                <div className="when">conf. {a.w}</div>
              </div>
            ))}
          </div>
        </section>

        <section className="card reveal">
          <div className="card-hd">
            <div>
              <h3>Signaux du modèle</h3>
              <div className="sub">Facteurs pondérés cette semaine</div>
            </div>
          </div>
          <div style={{ padding: '4px 18px 18px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { l: 'Saisonnalité grippale', v: 84 },
              { l: 'Historique ventes 12 sem.', v: 72 },
              { l: 'Stock fournisseur (Sanofi)', v: 58 },
              { l: 'Prescriptions zone locale', v: 46 },
              { l: 'Alerte sanitaire DGS', v: 28 },
              { l: 'Météo régionale', v: 17 },
            ].map((s, i) => (
              <div key={i}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                  <span>{s.l}</span><span className="num" style={{ color: 'var(--ink-3)' }}>{s.v}%</span>
                </div>
                <div style={{ height: 6, background: 'var(--bg-2)', borderRadius: 999 }}>
                  <div style={{ width: `${s.v}%`, height: '100%', background: 'var(--accent)', borderRadius: 999 }} />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}

function GenericView({ title, sub }) {
  return (
    <>
      <div className="page-hd">
        <div>
          <h1>{title}</h1>
          <p>{sub}</p>
        </div>
      </div>
      <div className="placeholder-canvas">
        <div>// Section prototypée — l'expérience complète sera développée lors du sprint suivant.</div>
        <div style={{ color: 'var(--ink-4)' }}>// Connectez l'API backend pour activer les flux temps réel.</div>
      </div>
    </>
  );
}

function AddMedModal({ onClose }) {
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h2>Ajouter un médicament</h2>
        <div className="sub">L'IA pré-remplit la classe et le seuil minimum à partir du nom.</div>
        <div className="form-grid">
          <div className="field full">
            <label>Nom commercial</label>
            <input defaultValue="Doliprane 500mg" />
          </div>
          <div className="field">
            <label>Code (DCI / EAN)</label>
            <input placeholder="MED-XXXXX" />
          </div>
          <div className="field">
            <label>Classe</label>
            <select defaultValue="Antalgique">
              <option>Antalgique</option>
              <option>Antibiotique</option>
              <option>Anti-inflammatoire</option>
              <option>Bronchodilatateur</option>
            </select>
          </div>
          <div className="field">
            <label>Quantité initiale</label>
            <input defaultValue="200" />
          </div>
          <div className="field">
            <label>Seuil minimum</label>
            <input defaultValue="100" />
          </div>
          <div className="field">
            <label>Date de péremption</label>
            <input defaultValue="2027-05-30" />
          </div>
          <div className="field">
            <label>Fournisseur</label>
            <input defaultValue="Sanofi" />
          </div>
        </div>
        <div className="modal-foot">
          <div className="ai-hint"><window.I.Sparkles size={12}/>Nerolina suggère : seuil <b style={{ marginLeft: 4 }}>120</b> (saisonnalité hiver)</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-ghost" onClick={onClose}>Annuler</button>
            <button className="btn btn-primary" onClick={onClose}><window.I.Check size={13}/>Ajouter au stock</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [t, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const [view, setView] = useState('dash');
  const [adding, setAdding] = useState(false);
  const [query, setQuery] = useState('');

  // Apply accent hue from tweaks
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--accent', `oklch(0.42 0.06 ${t.accentHue})`);
    root.style.setProperty('--accent-soft', `oklch(0.92 0.03 ${t.accentHue})`);
    root.style.setProperty('--accent-ink', `oklch(0.32 0.06 ${t.accentHue})`);
    if (t.dark) {
      root.style.setProperty('--bg', '#15140F');
      root.style.setProperty('--bg-2', '#1F1E18');
      root.style.setProperty('--surface', '#1A1914');
      root.style.setProperty('--ink', '#F5F2E9');
      root.style.setProperty('--ink-2', '#D2CDC0');
      root.style.setProperty('--ink-3', '#8E8A7C');
      root.style.setProperty('--ink-4', '#5C594F');
      root.style.setProperty('--line', 'rgba(245,242,233,0.10)');
      root.style.setProperty('--line-2', 'rgba(245,242,233,0.06)');
    } else {
      root.style.setProperty('--bg', '#F6F4EE');
      root.style.setProperty('--bg-2', '#EDEAE1');
      root.style.setProperty('--surface', '#FBFAF6');
      root.style.setProperty('--ink', '#14140F');
      root.style.setProperty('--ink-2', '#3A3A33');
      root.style.setProperty('--ink-3', '#6E6E63');
      root.style.setProperty('--ink-4', '#A5A498');
      root.style.setProperty('--line', 'rgba(20,20,15,0.09)');
      root.style.setProperty('--line-2', 'rgba(20,20,15,0.06)');
    }
    // density
    document.body.style.setProperty('--row-pad', t.density === 'compact' ? '8px' : t.density === 'comfy' ? '16px' : '12px');
  }, [t.accentHue, t.dark, t.density]);

  let body;
  if (view === 'dash') body = <DashView t={t} />;
  else if (view === 'stock') body = <StockView query={query} />;
  else if (view === 'ai') body = <AIView />;
  else if (view === 'alerts') body = <GenericView title="Centre d'alertes" sub="Toutes les alertes priorisées par criticité et impact patient." />;
  else if (view === 'expir') body = <GenericView title="Calendrier de péremption" sub="Vue calendaire des lots à écouler par fenêtre de 30, 60 et 90 jours." />;
  else if (view === 'orders') body = <GenericView title="Commandes & approvisionnements" sub="Bons de commande générés par l'IA, suivi des livraisons." />;
  else if (view === 'analytics') body = <GenericView title="Analytique avancée" sub="Cohortes de médicaments, marge, rotation, classes ABC/XYZ." />;
  else if (view === 'team') body = <GenericView title="Équipe & rôles" sub="Gestion des permissions pharmaciens, préparateurs, auditeurs." />;
  else body = <GenericView title="Paramètres" sub="Configuration de l'officine, intégrations et modèle Nerolina." />;

  return (
    <div className="app">
      <Sidebar view={view} setView={setView} />
      <main className="main">
        <Topbar view={view} openAdd={() => setAdding(true)} setQuery={setQuery} query={query} />
        {body}
      </main>

      {adding && <AddMedModal onClose={() => setAdding(false)} />}

      <window.TweaksPanel title="SmartPharma · Tweaks">
        <window.TweakSection label="Identité" />
        <window.TweakText label="Salutation" value={t.headline} onChange={v => setTweak('headline', v)} />
        <window.TweakSlider label="Teinte accent" value={t.accentHue} min={0} max={360} step={1} unit="°"
          onChange={v => setTweak('accentHue', v)} />
        <window.TweakSection label="Affichage" />
        <window.TweakRadio label="Densité" value={t.density}
          options={['compact', 'regular', 'comfy']}
          onChange={v => setTweak('density', v)} />
        <window.TweakToggle label="Thème sombre" value={t.dark}
          onChange={v => setTweak('dark', v)} />
        <window.TweakSection label="IA Nerolina" />
        <window.TweakToggle label="Afficher bandeau prédictif" value={t.showAIBanner}
          onChange={v => setTweak('showAIBanner', v)} />
      </window.TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
